 Installing Stock Inventory Real Time Report(PDF/XLS). All you need to do is follow the below mentioned points. 

1.First Install Below python Package in your system

sudo easy_install xlsxwriter 

2.Next Go to seeting / apps and search "Stock Inventory Real Time Report(PDF/XLS)" and Install 

And, you are done with installation. Congratulations!



